﻿using Microsoft.AspNetCore.Mvc;

namespace FileSystemCLI.Controllers
{
    public class FileCLIController1 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
