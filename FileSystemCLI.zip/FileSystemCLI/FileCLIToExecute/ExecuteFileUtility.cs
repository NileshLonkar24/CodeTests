﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileSystemUtility;
using Directory = FileSystemUtility.Directory;

namespace FileCLIToExecute
{
    public class ExecuteFileUtility
    {

        public void CallingFileCLIMethods()
        {

            
            var rootDirectory = new Directory("Root");

            // Creating directories and files
            rootDirectory.CreateDirectory("SubDirectory1");
            rootDirectory.CreateDirectory("SubDirectory2");

            var subDirectory1 = rootDirectory.GetSub_Directory("SubDirectory1");
            subDirectory1.CreateFile("File1.txt");
            subDirectory1.CreateFile("File2.txt");

            var subDirectory2 = rootDirectory.GetSub_Directory("SubDirectory2");
            subDirectory2.CreateDirectory("SubSubDirectory");
            var subSubDirectory = subDirectory2.GetSub_Directory("SubSubDirectory");
            subSubDirectory.CreateFile("File3.txt");

            // Navigating directories
            var currentDirectory = rootDirectory;
            Console.WriteLine("Current directory: " + currentDirectory.Name);

            Console.WriteLine("Navigating to SubDirectory1");
            currentDirectory = currentDirectory.GetSub_Directory("SubDirectory1");
            Console.WriteLine("Current directory: " + currentDirectory.Name);

            Console.WriteLine("Navigating to the parent directory");
            currentDirectory = currentDirectory.GetParentDirectory();
            Console.WriteLine("Current directory: " + currentDirectory.Name);

            // Listing contents
            Console.WriteLine("Listing contents of the current directory:");
            currentDirectory.ListContents();

            // Deleting a file
            Console.WriteLine("Deleting File1.txt");
            currentDirectory.DeleteFile("File1.txt");
            currentDirectory.ListContents();

            // Deleting a directory
            Console.WriteLine("Deleting SubSubDirectory");
            currentDirectory.DeleteDirectory("SubSubDirectory");
            currentDirectory.ListContents();

            // Searching for files
            Console.WriteLine("Searching for File2.txt");
            var foundFiles = currentDirectory.SearchFiles("File2.txt");
            foreach (var file in foundFiles)
            {
                Console.WriteLine("Found file: " + file.Name);
            }

            // Performing DFS
            Console.WriteLine("Performing depth-first search (DFS) starting from the root directory:");
            var fileList = rootDirectory.PerformDFS();
            foreach (var file in fileList)
            {
                Console.WriteLine("File: " + file.Name);
            }
            Console.ReadLine();
        }

    }

}
 
