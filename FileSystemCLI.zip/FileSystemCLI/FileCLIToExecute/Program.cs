﻿// See https://aka.ms/new-console-template for more information

using FileCLIToExecute;

Console.WriteLine("++++++++++++++++++++++++++++++++++ File System CLI TEST  ++++++++++++++++++++++++++++++++++++++++++++++++++");

ExecuteFileUtility executeFileUtility = new ExecuteFileUtility();

executeFileUtility.CallingFileCLIMethods();



Console.WriteLine("++++++++++++++++++++++++++++++++++ File System CLI TEST  ++++++++++++++++++++++++++++++++++++++++++++++++++");




 
