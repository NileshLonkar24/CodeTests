﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileSystemUtility
{
    public class File
    {
        public string Name { get; }
        public string Content { get; set; }

        public File(string name)
        {
            Name = name;
            Content = "";
        }
    }


}
