﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileSystemUtility
{
    public class Directory
    {
        public string Name { get; }
        public Directory Parent { get; }
        public List<Directory> Directories { get; }
        public List<File> Files { get; }

        public Directory(string name, Directory parent = null)
        {
            Name = name;
            Parent = parent;
            Directories = new List<Directory>();
            Files = new List<File>();
        }

        public void CreateDirectory(string name)
        {
            Directories.Add(new Directory(name, this));
        }

        public void CreateFile(string name)
        {
            Files.Add(new File(name));
        }

        public Directory GetSub_Directory(string name)
        {
            foreach (var directory in Directories)
            {
                if (directory.Name == name)
                {
                    return directory;
                }
            }
            return null;
        }

        public Directory GetParentDirectory()
        {
            return Parent;
        }

        public void ListContents()
        {
            Console.WriteLine("Directories:");
            foreach (var directory in Directories)
            {
                Console.WriteLine(directory.Name);
            }

            Console.WriteLine("Files:");
            foreach (var file in Files)
            {
                Console.WriteLine(file.Name);
            }
        }

        public void DeleteFile(string name)
        {
             File fileToRemove = null;
            foreach (var file in Files)
            {
                if (file.Name == name)
                {
                    fileToRemove = file;
                    break;
                }
            }

            if (fileToRemove != null)
            {
                Files.Remove(fileToRemove);
            }
        }

        public void DeleteDirectory(string name)
        {
            Directory directoryToRemove = null;
            foreach (var directory in Directories)
            {
                if (directory.Name == name)
                {
                    directoryToRemove = directory;
                    break;
                }
            }

            if (directoryToRemove != null)
            {
                Directories.Remove(directoryToRemove);
            }
        }

        public List< File> SearchFiles(string name)
        {
            var foundFiles = new List< File>();

            foreach (var file in Files)
            {
                if (file.Name == name)
                {
                    foundFiles.Add(file);
                }
            }

            foreach (var directory in Directories)
            {
                foundFiles.AddRange(directory.SearchFiles(name));
            }

            return foundFiles;
        }

        public List< File> PerformDFS()
        {
            var fileList = new List< File>();

            foreach (var file in Files)
            {
                fileList.Add(file);
            }

            foreach (var directory in Directories)
            {
                fileList.AddRange(directory.PerformDFS());
            }

            return fileList;
        }
    }
}
